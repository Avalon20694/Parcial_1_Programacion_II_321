package parcial_prog_2_321;

import Interfaces.Capacitable;
import Interfaces.Encargable;
import Utilidades.SupervivienteDuplicadoException;
import entidades.Constructor;
import entidades.Explorador;
import entidades.Medico;
import entidades.Refugio;
import entidades.Superviviente;
import java.util.List;

/**
 *
 * @author Molina Federico
 */
public class Parcial_Prog_2_321 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Refugio refugio = new Refugio("Horizonte");
          try {
        refugio.agregarSuperviviente(new Explorador(
                "EXP-101", "Ada", NivelExperiencia.SENIOR, true, 30));

        refugio.agregarSuperviviente(new Medico(
                "MED-220", "Bruno", NivelExperiencia.INTERMEDIO, true, 45));
        refugio.agregarSuperviviente(new Constructor(
                "CON-330", "Carla", NivelExperiencia.SENIOR, true, 25));
        refugio.agregarSuperviviente(new Explorador(
                "EXP-404", "Diego", NivelExperiencia.JUNIOR, true, 18));
      
            refugio.agregarSuperviviente(new Medico(
                    "EXP-101", "Ada", NivelExperiencia.JUNIOR, true, 12));
        } catch (SupervivienteDuplicadoException e) {
            System.out.println(e.getMessage());
        }

        System.out.println("Supervivientes registrados:");
        mostrarSupervivientes(refugio.obtenerSupervivientes());
        System.out.println("\nAptitudes:");
        mostrarAptitudes(refugio.obtenerSupervivientes());
        System.out.println("\nAsignacion de tareas:");
        asignarTareas(refugio.obtenerSupervivientes());
        System.out.println("\nCapacitaciones:");
        capacitarSupervivientes(refugio.obtenerSupervivientes());
        System.out.println("\nDisponibles con aptitud >= 50:");
        mostrarSupervivientes(refugio.obtenerDisponiblesConAptitudMinima(50));
        System.out.println("\nSupervivientes SENIOR:");
        mostrarSupervivientes(refugio.filtrarPorNivel(NivelExperiencia.SENIOR));
    }

    private static void mostrarSupervivientes(List<Superviviente> lista) {
        for(Superviviente s : lista)
        {
            System.out.println(s);
        }
    }

    private static void mostrarAptitudes(List<Superviviente> lista) {
        for(Superviviente s : lista)
        {
            System.out.println("Aptitud de " + s.obtenerNombre() + ": " + s.calcularAptitud());
        }
    }

    private static void asignarTareas(List<Superviviente> lista) {
        for(Superviviente s : lista)
        {
            if(s instanceof Encargable)
            {
                System.out.println(((Encargable) s).encargarTarea());
            }
            else System.out.println(s.obtenerNombre() + " no puede recibir tareas.");
        }
    }

    private static void capacitarSupervivientes(List<Superviviente> lista) {
        for(Superviviente s : lista)
        {
            if(s instanceof Capacitable)
            {
                System.out.println(((Capacitable) s).capacitarse());
            }
            else System.out.println(s.obtenerNombre() + " no puede capacitarse.");
        }
    }

}
