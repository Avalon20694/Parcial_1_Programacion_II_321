
package parcial_prog_2_321;

/**
 * Enumerado que determina el nivel de experiencia de un superviviente.
 * @author Molina Federico
 */
public enum NivelExperiencia {
    JUNIOR, INTERMEDIO, SENIOR;
}
