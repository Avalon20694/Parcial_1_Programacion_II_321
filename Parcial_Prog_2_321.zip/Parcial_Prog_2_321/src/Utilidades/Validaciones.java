
package Utilidades;

import java.util.Objects;

/**
 * Clase con metodos auxiliares para validar datos.
 * @author Molina Federico
 */
public class Validaciones 
{
    
    private Validaciones()
    {
        
    }
    /**
     * Valida una cadena (String) para asegurarse que no sea nula, no este vacia, o no este compuesta de caracteres en blanco.
     * @param cadena la cadena a validar.
     * @param nombre el nombre de la cadena o valor. Utilizado para devolver excepciones precisas.
     * @return la cadena ya validada.
     */
    public static String validarCadena(String cadena, String nombre)
    {
        Objects.requireNonNull(cadena, nombre + " no puede ser nulo.");
        if(cadena.isEmpty()) throw new IllegalArgumentException(nombre + " no puede estar vacio ni estar compuesto por caracteres en blanco.");
        return cadena;
    }
    
    /**
     * Valida un valor entero con la condicion de que no sea negativo o no sea cero.
     * @param valor el valor entero a validar.
     * @param nombre el nombre o referencia del valor. Utilizado para devolver excepciones precisas.
     * @return el valor entero ya validado.
     */
    public static int validarPositivo(int valor, String nombre)
    {
        if(valor <= 0) throw new IllegalArgumentException(nombre + " debe ser un valor positivo o igual a cero.");
        return valor;
    }
    
    /**
     * Valida un valor entero con la condicion de que no sea negativo.
     * @param valor el valor entero a validar.
     * @param nombre el nombre o referencia del valor. Utilizado para devolver excepciones precisas.
     * @return el valor entero ya validado.
     */
    public static int validarNoNegativo(int valor, String nombre)
    {
        if(valor < 0) throw new IllegalArgumentException(nombre + " no puede ser un valor negativo");
        return valor;
    }
    
}
