
package Utilidades;

/**
 *
 * @author Molina Federico
 */
public class SupervivienteDuplicadoException extends Exception
{
    private static final String MENSAJE_POR_DEFECTO = "Superviviente duplicado";
    
    public SupervivienteDuplicadoException()
    {
        super(MENSAJE_POR_DEFECTO);
    }
    public SupervivienteDuplicadoException(String mensaje)
    {
        super(mensaje);
    }
}
