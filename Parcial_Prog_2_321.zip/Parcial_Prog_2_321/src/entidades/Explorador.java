package entidades;

import Interfaces.Encargable;
import Utilidades.Validaciones;
import parcial_prog_2_321.NivelExperiencia;

/**
 * Clase representando un Superviviente de especialidad Explorador.
 * @author Molina Federico
 */
public class Explorador extends Superviviente implements Encargable
{
    private int resistencia;
    
    public Explorador(String codigo, String nombre, NivelExperiencia nivel, boolean disponible, int resistencia)
    {
        super(codigo, nombre, disponible, nivel);
        this.resistencia = Validaciones.validarPositivo(resistencia, "Resistencia");
    }
    /**
     * Getter para el atributo resistencia.
     * @return valor del atributo resistencia.
     */
    public int obtenerResistencia()
    {
        return this.resistencia;
    }
    
    /**
     * Implementacion del metodo abstracto de la clase Superviviente
     * @return valor calculado basado en atributos y logica interna.
     */
    @Override
    public int calcularAptitud()
    {
        return this.obtenerResistencia() * 2;
    }
    /**
     * Implementacion de metodo abstracto de la interfaz Encargable. Simula el tomar cargo de una tarea.
     * @return Cadena representado la accion.
     */
    @Override
    public String encargarTarea()
    {
        return this.obtenerNombre() + " el Explorador se encarga de explorar un area.";
    }
    
    @Override
    public String toString()
    {
        return "Explorador. " + super.toString() + ", Resistencia: " + this.obtenerResistencia();
    }
}
