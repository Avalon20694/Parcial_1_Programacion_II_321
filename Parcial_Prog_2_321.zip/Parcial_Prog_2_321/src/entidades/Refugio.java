package entidades;

import Utilidades.SupervivienteDuplicadoException;
import Utilidades.Validaciones;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import parcial_prog_2_321.NivelExperiencia;

/**
 * Clase que representa un refugio para Sobrevivientes de un post-apocalipsis.
 *
 * @author Molina Federico
 */
public class Refugio {

    private final String nombre;
    private final List<Superviviente> supervivientes;

    public Refugio(String nombre) {
        this.nombre = Validaciones.validarCadena(nombre, "Nombre del refugio");
        this.supervivientes = new ArrayList<>();
    }

    /**
     * Agrega un Superviviente a la lista interna del refugio, validandolo en el
     * proceso.
     *
     * @param superviviente El Superviviente a validar y agregar.
     * @return true si el Superviviente fue agregado.
     * @throws SupervivienteDuplicadoException Cuando el Superviviente ya existe
     * dentro del refugio.
     */
    public boolean agregarSuperviviente(Superviviente superviviente) throws SupervivienteDuplicadoException {
        Objects.requireNonNull(superviviente);
        for (Superviviente s : this.supervivientes) {
            if (superviviente.equals(s)) {
                throw new SupervivienteDuplicadoException("No se pudo registrar: Ya existe un superviviente con codigo " + superviviente.obtenerCodigo() + " y nombre " + superviviente.obtenerNombre() + ".");                
            }
        }
        return this.supervivientes.add(superviviente);
    }

    /**
     * Obtiene una copia de la lista interna de Supervivientes.
     *
     * @return Lista copiada de la lista interna de Supervivientes.
     */
    public List<Superviviente> obtenerSupervivientes() {
        return List.copyOf(supervivientes);
    }

    /**
     * Retorna una nueva lista filtrada por el NivelExperiencia de los
     * Supervivientes.
     *
     * @param nivel El NivelExperiencia a considerar.
     * @return Nueva lista compuesta de los Supervivientes con el
     * NivelExperiencia indicado.
     */
    public List<Superviviente> filtrarPorNivel(NivelExperiencia nivel) {
        List<Superviviente> listaFiltrada = new ArrayList<>();
        for (Superviviente s : this.supervivientes) {
            if (s.obtenerNivelExperiencia().equals(nivel)) {
                listaFiltrada.add(s);
            }
        }
        return listaFiltrada;
    }

    /**
     * Retorna una nueva lista filtrada por un minimo de aptitud requerida por
     * el Superviviente.
     *
     * @param minimo El valor minimo de aptitud a considerar. El superviviente
     * debe tener igual o mayor aptitud para ser considerado.
     * @return Nueva lista compuesta de los Supervivientes con la aptitud minima
     * indicada.
     */
    public List<Superviviente> obtenerDisponiblesConAptitudMinima(int minimo) {
        Validaciones.validarNoNegativo(minimo, "Aptitud");
        List<Superviviente> listaFiltrada = new ArrayList<>();
        for (Superviviente s : this.supervivientes) {
            if (s.calcularAptitud() >= minimo) {
                listaFiltrada.add(s);
            }
        }
        return listaFiltrada;
    }

}
