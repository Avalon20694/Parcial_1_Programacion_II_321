package entidades;

import Interfaces.Capacitable;
import Interfaces.Encargable;
import Utilidades.Validaciones;
import parcial_prog_2_321.NivelExperiencia;

/**
 * Clase representando un Superviviente de especialidad Constructor.
 * @author Molina Federico
 */
public class Constructor extends Superviviente implements Encargable, Capacitable
{
    private int habilidadTecnica;
    
    public Constructor(String codigo, String nombre, NivelExperiencia nivel, boolean disponible, int habilidadTecnica)
    {
        super(codigo, nombre, disponible, nivel);
        this.habilidadTecnica = Validaciones.validarPositivo(habilidadTecnica, "Habilidad Tecnica");
    }
    
    public int obtenerHabilidadTecnica()
    {
        return this.habilidadTecnica;
    }
    
    /**
     * Implementacion del metodo abstracto de la clase Superviviente
     * @return valor calculado basado en atributos y logica interna.
     */
    @Override
    public int calcularAptitud()
    {
        return this.obtenerHabilidadTecnica() * 3;
    }
    
    /**
     * Implementacion de metodo abstracto de la interfaz Encargable. Simula el tomar cargo de una tarea.
     * @return Cadena representado la accion.
     */
    @Override
    public String encargarTarea() {
        return this.obtenerNombre() + " el Constructor se encarga de tareas de reparacion.";
    }

    @Override
    public String capacitarse() {
        return this.obtenerNombre() + " el Constructor se capacita en planes de expansion.";
    }
    
    @Override
    public String toString()
    {
        return "Constructor. " + super.toString() + ", Habilidad Tecnica: " + this.obtenerHabilidadTecnica();
    }
}
