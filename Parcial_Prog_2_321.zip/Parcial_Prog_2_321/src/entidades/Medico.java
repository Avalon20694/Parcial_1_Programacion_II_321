package entidades;

import Interfaces.Capacitable;
import Utilidades.Validaciones;
import parcial_prog_2_321.NivelExperiencia;

/**
 * Clase representando un Superviviente de especialidad Medico.
 *
 * @author Molina Federico
 */
public class Medico extends Superviviente implements Capacitable {

    private int conocimientos;

    public Medico(String codigo, String nombre, NivelExperiencia nivel, boolean disponible, int conocimientos) {
        super(codigo, nombre, disponible, nivel);
        this.conocimientos = Validaciones.validarPositivo(conocimientos, "Conocimientos");
    }

    public int obtenerConocimientos() {
        return this.conocimientos;
    }

    /**
     * Implementacion del metodo abstracto de la clase Superviviente
     *
     * @return valor calculado basado en atributos y logica interna.
     */
    @Override
    public int calcularAptitud() {
        return this.obtenerConocimientos() + 10;
    }

    @Override
    public String capacitarse() {
        return this.obtenerNombre() + " el Medico se capacita en primeros auxilios.";
    }

    @Override
    public String toString() {
        return "Medico. " + super.toString() + ", Conocimientos: " + this.obtenerConocimientos();
    }
}
