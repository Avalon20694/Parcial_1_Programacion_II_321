package entidades;

import Utilidades.Validaciones;
import java.util.Objects;
import parcial_prog_2_321.NivelExperiencia;

/**
 * Esta clase representa supervivientes de un evento post apocaliptico.
 * @author Molina Federico
 */
public abstract class Superviviente 
{
    private final String codigo;
    private final String nombre;
    private final NivelExperiencia nivel;
    private boolean disponible;
    
    public Superviviente(String codigo, String nombre, boolean disponible, NivelExperiencia nivel)
    {
        this.codigo = Validaciones.validarCadena(codigo, "Codigo del superviviente");
        this.nombre = Validaciones.validarCadena(nombre, "Nombre del superviviente");
        this.nivel = this.validarNivelExperiencia(nivel);
        this.disponible = disponible;
        
    }
    /**
     * Getter para el atributo codigo.
     * @return valor del atributo codigo.
     */
    public String obtenerCodigo()
    {
        return this.codigo;
    }
    /**
     * Getter para el atributo nombre.
     * @return valor del atributo nombre
     */
    public String obtenerNombre()
    {
        return this.nombre;
    }
    /**
     * Getter para el atributo nivel.
     * @return valor del atributo nivel.
     */
    public NivelExperiencia obtenerNivelExperiencia()
    {
        return this.nivel;
    }
    /**
     * Getter para el atributo disponible.
     * @return valor del atributo disponible.
     */
    public boolean estaDisponible()
    {
        return this.disponible;
    }
    
    /**
     * Metodo para validar que el NivelExperiencia no sea nulo.
     * @param nivel El valor NivelExperiencia a validar.
     * @return el valor NivelExperiencia ya validado.
     * @throws IllegalArgumentException si el valor es nulo.
     */
    protected static NivelExperiencia validarNivelExperiencia(NivelExperiencia nivel)
    {
        Objects.requireNonNull(nivel, "El nivel no puede ser nulo.");
        return nivel;
    }
    /**
     * Metodo para calcular el nivel de aptitud. Cada clase heredante debe implementar su propia logica.
     * @return valor entero.
     */
    public abstract int calcularAptitud();

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 59 * hash + Objects.hashCode(this.codigo);
        return hash;
    }
    
    /**
     * Metodo para determinar si dos Supervivientes son iguales, basado en el nombre y codigo de los mismos, indistinto de su expecialidad.
     * @param sup el objeto (en este caso Superviviente) a comparar.
     * @return true si el Superviviente tiene el mismo nombre y codigo.
     */
    public boolean equals(Superviviente sup)
    {
        return this.obtenerCodigo().equals(sup.obtenerCodigo()) && this.obtenerNombre().equals(sup.obtenerNombre());
    }
    
    @Override
    public String toString()
    {
        return "Nombre: " + this.obtenerNombre() + ", Codigo: " + this.obtenerCodigo() + ", Nivel de Experiencia: " + this.obtenerNivelExperiencia();
    }
    
}
