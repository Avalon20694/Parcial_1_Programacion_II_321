package Interfaces;

/**
 *Interfaz para dictaminar el comportamiento de capacitarse en una actividad.
 * @author Molina Federico
 */
public interface Capacitable 
{
    String capacitarse();    
}
