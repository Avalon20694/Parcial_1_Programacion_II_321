package Interfaces;

/**
 * Interfaz para dictaminar el comportamiento de tomar cargo de una tarea.
 * @author Molina Federico
 */
public interface Encargable 
{
    String encargarTarea();
    
}
